import { Router } from "express";
import { db } from "@workspace/db";
import { screensTable, schedulesTable, playlistsTable, activityTable, mediaPlaysTable, devicesTable } from "@workspace/db";
import { eq, and, desc, gte, inArray, or, isNull, isNotNull } from "drizzle-orm";
import { randomBytes } from "crypto";
import {
  UpdateScreenBody,
  UpdateScreenParams,
  GetScreenParams,
  DeleteScreenParams,
  PairScreenBody,
} from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/requireAdmin";

const router = Router();

function generateCode(): string {
  return randomBytes(4).toString("hex").toUpperCase();
}

router.post("/pair", async (req, res) => {
  const body = PairScreenBody.parse(req.body);
  const codeUpper = body.pairingCode.trim().toUpperCase();

  const [screen] = await db
    .select()
    .from(screensTable)
    .where(eq(screensTable.code, codeUpper))
    .limit(1);

  if (!screen) {
    res.status(404).json({ error: "Código de pareamento inválido. Verifique o código na página Telas." });
    return;
  }

  await db
    .update(screensTable)
    .set({ lastSeen: new Date() })
    .where(eq(screensTable.id, screen.id));

  await db.insert(activityTable).values({
    userId: screen.userId ?? undefined,
    action: "paired",
    entityType: "screen",
    entityName: screen.name,
  });

  res.status(201).json({
    id: screen.id,
    name: screen.name,
    code: screen.code,
    location: screen.location ?? null,
    status: screen.status,
    createdAt: screen.createdAt.toISOString(),
  });
});

router.get("/", async (req, res) => {
  if (!req.isAuthenticated()) { res.status(401).json({ error: "Unauthorized" }); return; }
  const userId = String((req.user as any).id);
  const role = (req.user as any).role;

  // For operators: also include screens linked to their approved devices (handles legacy null-userId screens)
  let whereClause: ReturnType<typeof eq> | ReturnType<typeof or> | undefined;
  if (role !== "admin") {
    const userDevices = await db
      .select({ screenCode: devicesTable.screenCode })
      .from(devicesTable)
      .where(and(eq(devicesTable.userId, userId), isNotNull(devicesTable.screenCode)));
    const deviceCodes = userDevices.map(d => d.screenCode!).filter(Boolean);

    whereClause = deviceCodes.length > 0
      ? or(eq(screensTable.userId, userId), inArray(screensTable.code, deviceCodes))
      : eq(screensTable.userId, userId);

    // Self-heal: assign any null-userId screens that belong to this user's devices
    if (deviceCodes.length > 0) {
      await db.update(screensTable)
        .set({ userId })
        .where(and(isNull(screensTable.userId), inArray(screensTable.code, deviceCodes)));
    }
  }

  const rows = await db
    .select({
      id: screensTable.id,
      name: screensTable.name,
      clientId: screensTable.clientId,
      code: screensTable.code,
      location: screensTable.location,
      status: screensTable.status,
      lastSeen: screensTable.lastSeen,
      defaultPlaylistId: screensTable.defaultPlaylistId,
      resolution: screensTable.resolution,
      tags: screensTable.tags,
      lastScreenshot: screensTable.lastScreenshot,
      powerOnTime: screensTable.powerOnTime,
      powerOffTime: screensTable.powerOffTime,
      powerScheduleJson: screensTable.powerScheduleJson,
      createdAt: screensTable.createdAt,
    })
    .from(screensTable)
    .where(whereClause)
    .orderBy(screensTable.createdAt);

  const TWO_MINUTES = 2 * 60 * 1000;
  const nowMs = Date.now();
  const nowDate = new Date();
  const todayStart = new Date(nowDate); todayStart.setHours(0, 0, 0, 0);

  // Batch query: recent plays for ALL screens (no N+1)
  const screenIds = rows.map((r) => r.id);
  const lastPlayByScreen = new Map<number, { mediaName: string; mediaType: string; playedAt: Date }>();
  const playsTodayByScreen = new Map<number, number>();

  if (screenIds.length > 0) {
    const recentPlays = await db.select({
      screenId: mediaPlaysTable.screenId,
      mediaName: mediaPlaysTable.mediaName,
      mediaType: mediaPlaysTable.mediaType,
      playedAt: mediaPlaysTable.playedAt,
    })
      .from(mediaPlaysTable)
      .where(and(inArray(mediaPlaysTable.screenId, screenIds), gte(mediaPlaysTable.playedAt, todayStart)))
      .orderBy(desc(mediaPlaysTable.playedAt))
      .limit(2000);

    for (const p of recentPlays) {
      if (!p.screenId) continue;
      if (!lastPlayByScreen.has(p.screenId)) lastPlayByScreen.set(p.screenId, p as any);
      playsTodayByScreen.set(p.screenId, (playsTodayByScreen.get(p.screenId) ?? 0) + 1);
    }
  }

  // Batch device lookup by screen code (no N+1)
  const screenCodes = rows.map(r => r.code).filter(Boolean);
  const deviceByCode = new Map<string, { serial: string; name: string | null; status: string }>();
  if (screenCodes.length > 0) {
    const linkedDevices = await db.select({
      screenCode: devicesTable.screenCode,
      serial: devicesTable.serial,
      name: devicesTable.name,
      status: devicesTable.status,
    }).from(devicesTable).where(inArray(devicesTable.screenCode, screenCodes));
    for (const d of linkedDevices) {
      if (d.screenCode) deviceByCode.set(d.screenCode, { serial: d.serial, name: d.name ?? null, status: d.status });
    }
  }

  const result = await Promise.all(
    rows.map(async (s) => {
      const [activeScheduleRow] = await db
        .select({ playlistName: playlistsTable.name, publishedAt: schedulesTable.createdAt })
        .from(schedulesTable)
        .leftJoin(playlistsTable, eq(schedulesTable.playlistId, playlistsTable.id))
        .where(and(eq(schedulesTable.screenId, s.id), eq(schedulesTable.active, true)))
        .limit(1);

      let defaultPlaylistName: string | null = null;
      if (s.defaultPlaylistId) {
        const [pl] = await db
          .select({ name: playlistsTable.name })
          .from(playlistsTable)
          .where(eq(playlistsTable.id, s.defaultPlaylistId));
        defaultPlaylistName = pl?.name ?? null;
      }

      const computedStatus = s.lastSeen
        ? (nowMs - s.lastSeen.getTime() < TWO_MINUTES ? "online" : "offline")
        : "unknown";

      const lp = lastPlayByScreen.get(s.id);

      return {
        ...s,
        status: computedStatus,
        clientName: null,
        activePlaylistName: activeScheduleRow?.playlistName ?? null,
        playlistPublishedAt: activeScheduleRow?.publishedAt?.toISOString() ?? null,
        defaultPlaylistName,
        resolution: s.resolution ?? null,
        tags: s.tags ?? null,
        lastScreenshot: s.lastScreenshot ?? null,
        lastSeen: s.lastSeen?.toISOString() ?? null,
        createdAt: s.createdAt.toISOString(),
        lastPlay: lp ? { mediaName: lp.mediaName, mediaType: lp.mediaType, playedAt: lp.playedAt.toISOString() } : null,
        playsToday: playsTodayByScreen.get(s.id) ?? 0,
        device: deviceByCode.get(s.code) ?? null,
      };
    })
  );

  res.json(result);
});

router.post("/", async (req, res) => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const callerUserId = String((req.user as any).id);
  const role = (req.user as any).role;
  const isAdmin = role === "admin";
  const { name, location, timezone, powerOnTime, powerOffTime, panelWidth, panelHeight, assignedUserId } = req.body as {
    name: string; location?: string; timezone?: string;
    powerOnTime?: string | null; powerOffTime?: string | null;
    panelWidth?: number | null; panelHeight?: number | null;
    assignedUserId?: string;
  };
  // Admin can create a screen on behalf of a specific operator
  const userId = (isAdmin && assignedUserId) ? assignedUserId : callerUserId;
  const code = generateCode();
  const [screen] = await db
    .insert(screensTable)
    .values({
      name, location, code, userId,
      ...(timezone ? { timezone } : {}),
      ...(powerOnTime !== undefined ? { powerOnTime } : {}),
      ...(powerOffTime !== undefined ? { powerOffTime } : {}),
      ...(panelWidth !== undefined ? { panelWidth } : {}),
      ...(panelHeight !== undefined ? { panelHeight } : {}),
    })
    .returning();
  await db.insert(activityTable).values({ userId, action: "created", entityType: "screen", entityName: screen.name });
  res.status(201).json({
    ...screen,
    clientName: null,
    activePlaylistName: null,
    defaultPlaylistName: null,
    lastSeen: null,
    createdAt: screen.createdAt.toISOString(),
  });
});

router.get("/:id", async (req, res) => {
  const { id } = GetScreenParams.parse({ id: Number(req.params.id) });
  const [screen] = await db
    .select()
    .from(screensTable)
    .where(eq(screensTable.id, id));

  if (!screen) { res.status(404).json({ error: "Not found" }); return; }

  const [activeScheduleRow] = await db
    .select({ playlistName: playlistsTable.name })
    .from(schedulesTable)
    .leftJoin(playlistsTable, eq(schedulesTable.playlistId, playlistsTable.id))
    .where(and(eq(schedulesTable.screenId, id), eq(schedulesTable.active, true)))
    .limit(1);

  let defaultPlaylistName: string | null = null;
  if (screen.defaultPlaylistId) {
    const [pl] = await db
      .select({ name: playlistsTable.name })
      .from(playlistsTable)
      .where(eq(playlistsTable.id, screen.defaultPlaylistId));
    defaultPlaylistName = pl?.name ?? null;
  }

  res.json({
    ...screen,
    clientName: null,
    activePlaylistName: activeScheduleRow?.playlistName ?? null,
    defaultPlaylistName,
    lastSeen: screen.lastSeen?.toISOString() ?? null,
    createdAt: screen.createdAt.toISOString(),
  });
});

router.patch("/:id", async (req, res) => {
  if (!req.isAuthenticated()) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { id } = UpdateScreenParams.parse({ id: Number(req.params.id) });
  const body = UpdateScreenBody.parse(req.body);
  const role = (req.user as any).role;
  const userId = String((req.user as any).id);
  // Operators can only update their own screens
  if (role !== "admin") {
    const [existing] = await db.select({ userId: screensTable.userId }).from(screensTable).where(eq(screensTable.id, id));
    if (!existing || existing.userId !== userId) { res.status(403).json({ error: "Sem permissão" }); return; }
  }
  const [screen] = await db.update(screensTable).set(body).where(eq(screensTable.id, id)).returning();
  if (!screen) { res.status(404).json({ error: "Not found" }); return; }
  const uid = req.isAuthenticated() ? String((req.user as any).id) : undefined;
  await db.insert(activityTable).values({ userId: uid, action: "updated", entityType: "screen", entityName: screen.name });

  // Sincroniza nome no dispositivo vinculado
  if (body.name !== undefined) {
    await db.update(devicesTable)
      .set({ name: body.name })
      .where(eq(devicesTable.screenCode, screen.code));
  }

  let defaultPlaylistName: string | null = null;
  if (screen.defaultPlaylistId) {
    const [pl] = await db
      .select({ name: playlistsTable.name })
      .from(playlistsTable)
      .where(eq(playlistsTable.id, screen.defaultPlaylistId));
    defaultPlaylistName = pl?.name ?? null;
  }

  res.json({
    ...screen,
    clientName: null,
    activePlaylistName: null,
    defaultPlaylistName,
    lastSeen: screen.lastSeen?.toISOString() ?? null,
    createdAt: screen.createdAt.toISOString(),
  });
});

router.delete("/:id", async (req, res) => {
  if (!req.isAuthenticated()) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { id } = DeleteScreenParams.parse({ id: Number(req.params.id) });
  const role = (req.user as any).role;
  const userId = String((req.user as any).id);

  // Find the screen first to check ownership
  const existing = await db.select().from(screensTable).where(eq(screensTable.id, id)).limit(1);
  if (!existing[0]) { res.status(404).json({ error: "Not found" }); return; }

  // Somente administradores podem excluir telas
  if (role !== "admin") {
    res.status(403).json({ error: "Apenas administradores podem excluir telas" }); return;
  }

  const [screen] = await db.delete(screensTable).where(eq(screensTable.id, id)).returning();
  await db.insert(activityTable).values({ userId, action: "deleted", entityType: "screen", entityName: screen.name });
  // Volta dispositivo vinculado para "pending" e limpa screenCode
  // Sem isso, o /check/:serial recriaria a tela automaticamente ao próximo heartbeat
  await db.update(devicesTable)
    .set({ screenCode: null, status: "pending" })
    .where(eq(devicesTable.screenCode, screen.code));
  res.status(204).send();
});

export default router;
