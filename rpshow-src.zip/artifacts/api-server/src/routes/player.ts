import { Router } from "express";
import { db } from "@workspace/db";
import { screensTable, schedulesTable, mediaTable, mediaPlaysTable, emergencyAlertsTable } from "@workspace/db";
import { eq, and, inArray } from "drizzle-orm";
import { GetPlayerPlaylistParams } from "@workspace/api-zod";
import { loadPublishedOrLiveItems } from "../lib/playlist-publish";

async function resolveLayoutZones(layoutJson: string | null | undefined): Promise<Record<string, { url: string; type: string }> | undefined> {
  if (!layoutJson) return undefined;
  try {
    const layout = JSON.parse(layoutJson) as { logo?: { mediaId: number }; sidebar?: { mediaId: number } };
    const zoneMap: { key: string; mediaId: number }[] = [];
    if (layout.logo?.mediaId)    zoneMap.push({ key: "logo",    mediaId: layout.logo.mediaId });
    if (layout.sidebar?.mediaId) zoneMap.push({ key: "sidebar", mediaId: layout.sidebar.mediaId });
    if (!zoneMap.length) return undefined;
    const ids = zoneMap.map((z) => z.mediaId);
    const medias = await db.select({ id: mediaTable.id, url: mediaTable.url, type: mediaTable.type })
      .from(mediaTable).where(inArray(mediaTable.id, ids));
    const byId = new Map(medias.map((m) => [m.id, m]));
    const result: Record<string, { url: string; type: string }> = {};
    for (const { key, mediaId } of zoneMap) {
      const m = byId.get(mediaId);
      if (m) result[key] = { url: m.url, type: m.type };
    }
    return Object.keys(result).length ? result : undefined;
  } catch { return undefined; }
}

const router = Router();

router.post("/:screenCode/heartbeat", async (req, res) => {
  const { screenCode } = GetPlayerPlaylistParams.parse({ screenCode: req.params.screenCode });
  const [screen] = await db
    .select({ id: screensTable.id, status: screensTable.status })
    .from(screensTable)
    .where(eq(screensTable.code, screenCode));
  if (!screen) { res.status(404).json({ error: "Screen not found" }); return; }
  const { resolution } = req.body as { resolution?: string };
  const update: { status: string; lastSeen: Date; resolution?: string; onlineSince?: Date } = {
    status: "online", lastSeen: new Date(),
  };
  // Track when screen came back online (transition from offline/unknown → online)
  if (screen.status !== "online") update.onlineSince = new Date();
  if (resolution) {
    const normalized = resolution.replace(/(\d+)\.?\d*/g, (m) => String(Math.round(Number(m))));
    update.resolution = normalized;
  }
  await db.update(screensTable).set(update).where(eq(screensTable.id, screen.id));
  res.status(204).send();
});

router.post("/:screenCode/play", async (req, res) => {
  const { screenCode } = GetPlayerPlaylistParams.parse({ screenCode: req.params.screenCode });
  const [screen] = await db
    .select({ id: screensTable.id, name: screensTable.name, userId: screensTable.userId })
    .from(screensTable)
    .where(eq(screensTable.code, screenCode));

  if (!screen) { res.status(404).json({ error: "Screen not found" }); return; }

  const { mediaId, mediaName, mediaType, durationSeconds } = req.body as {
    mediaId?: number;
    mediaName: string;
    mediaType: string;
    durationSeconds?: number;
  };

  await db.insert(mediaPlaysTable).values({
    userId: screen.userId ?? null,
    screenId: screen.id,
    screenCode,
    screenName: screen.name,
    mediaId: mediaId ?? null,
    mediaName: mediaName ?? "Desconhecido",
    mediaType: mediaType ?? "image",
    durationSeconds: durationSeconds ?? null,
  });

  // Atualiza preview da tela com a URL da mídia atual (imagens)
  const { currentMediaUrl } = req.body as { currentMediaUrl?: string };
  if (currentMediaUrl && (mediaType === "image" || mediaType === "video")) {
    await db.update(screensTable).set({ lastScreenshot: currentMediaUrl }).where(eq(screensTable.id, screen.id));
  }

  res.status(204).send();
});

async function loadPlaylistPayload(playlistId: number) {
  const loaded = await loadPublishedOrLiveItems(playlistId);
  const layoutZones = await resolveLayoutZones(loaded.layoutJson);
  return {
    layoutZones,
    transitionEffect: loaded.transitionEffect,
    publishedAt: loaded.publishedAt ? loaded.publishedAt.toISOString() : null,
    fromPublished: loaded.fromPublished,
    items: loaded.items.map((i) => ({
      mediaId: i.mediaId ?? null,
      mediaUrl: i.mediaUrl ?? "",
      mediaType: i.mediaType ?? "image",
      durationSeconds: i.durationSeconds,
      mediaName: i.mediaName ?? "",
      metaJson: i.metaJson ?? null,
      objectFit: i.objectFit ?? "contain",
    })),
  };
}

router.get("/:screenCode", async (req, res) => {
  const { screenCode } = GetPlayerPlaylistParams.parse({ screenCode: req.params.screenCode });

  const [screen] = await db.select().from(screensTable).where(eq(screensTable.code, screenCode));
  if (!screen) { res.status(404).json({ error: "Screen not found" }); return; }

  // Check if this specific screen is blocked by admin
  if (screen.blocked) {
    // Still mark lastSeen so admin sees it online (but blocked)
    await db.update(screensTable).set({ lastSeen: new Date() }).where(eq(screensTable.id, screen.id));
    res.json({ blocked: true, items: [], screenName: screen.name, layoutZones: null, emergencyAlert: null });
    return;
  }

  await db.update(screensTable).set({ status: "online", lastSeen: new Date() }).where(eq(screensTable.id, screen.id));

  // Check for active emergency alert (highest priority — overrides everything)
  let emergencyAlert: { id: number; message: string; bgColor: string; textColor: string } | null = null;
  if (screen.userId) {
    const now2 = new Date();
    const alerts = await db.select().from(emergencyAlertsTable)
      .where(and(eq(emergencyAlertsTable.userId, screen.userId), eq(emergencyAlertsTable.isActive, true)));
    const active = alerts.find(a => !a.expiresAt || a.expiresAt > now2);
    if (active) {
      emergencyAlert = { id: active.id, message: active.message, bgColor: active.bgColor, textColor: active.textColor };
    }
  }

  const now = new Date();

  // Fetch all active schedules for this screen
  const allSchedules = await db
    .select()
    .from(schedulesTable)
    .where(and(eq(schedulesTable.screenId, screen.id), eq(schedulesTable.active, true)));

  // Priority 1: date-specific schedules (startAt is set) — promos/campaigns
  const dateSchedule = allSchedules.find((s) => {
    if (!s.startAt) return false;
    const started = s.startAt <= now;
    const notEnded = !s.endAt || s.endAt >= now;
    return started && notEnded;
  });

  // Priority 2: time-of-day recurring schedules (no startAt)
  const BRT_OFFSET_MS = -3 * 60 * 60 * 1000;
  const nowBRT = new Date(now.getTime() + BRT_OFFSET_MS);
  const pad = (n: number) => String(n).padStart(2, "0");
  const curTimeBRT = `${pad(nowBRT.getUTCHours())}:${pad(nowBRT.getUTCMinutes())}`;
  const curDayBRT = nowBRT.getUTCDay();

  const recurringSchedule = dateSchedule
    ? undefined
    : allSchedules.find((s) => {
        if (s.startAt) return false;

        if (s.daysOfWeek) {
          const allowed = s.daysOfWeek.split(",").map((d) => parseInt(d.trim(), 10));
          if (!allowed.includes(curDayBRT)) return false;
        }

        if (s.startTime && s.endTime) {
          const toMins = (t: string) => {
            const [h, m] = t.split(":").map(Number);
            return h * 60 + (m || 0);
          };
          const startM = toMins(s.startTime);
          // "00:00" endTime means midnight (end of day = 24*60)
          const endM   = s.endTime === "00:00" ? 24 * 60 : toMins(s.endTime);
          const curM   = toMins(curTimeBRT);
          if (curM < startM || curM >= endM) return false;
        }

        return true;
      });

  const schedule = dateSchedule ?? recurringSchedule;

  // Priority 3: fallback to default playlist (24/7 content)
  const powerOnTime  = screen.powerOnTime  ?? null;
  const powerOffTime = screen.powerOffTime ?? null;
  const powerScheduleJson = screen.powerScheduleJson ?? null;

  const timezone = screen.timezone ?? "America/Sao_Paulo";

  const panelWidth  = screen.panelWidth  ?? null;
  const panelHeight = screen.panelHeight ?? null;

  const basePayload = { screenId: screen.id, screenName: screen.name, timezone, powerOnTime, powerOffTime, powerScheduleJson, emergencyAlert, panelWidth, panelHeight };

  if (!schedule) {
    if (!screen.defaultPlaylistId) {
      res.json({ ...basePayload, items: [] });
      return;
    }
    const payload = await loadPlaylistPayload(screen.defaultPlaylistId);
    res.json({
      ...basePayload,
      playlistId: screen.defaultPlaylistId,
      layoutZones: payload.layoutZones,
      transitionEffect: payload.transitionEffect,
      publishedAt: payload.publishedAt,
      isDefault: true,
      items: payload.items,
    });
    return;
  }

  const payload = await loadPlaylistPayload(schedule.playlistId);

  res.json({
    ...basePayload,
    playlistId: schedule.playlistId,
    layoutZones: payload.layoutZones,
    transitionEffect: payload.transitionEffect,
    publishedAt: payload.publishedAt,
    isDefault: false,
    items: payload.items,
  });
});

export default router;
